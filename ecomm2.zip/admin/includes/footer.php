<!-- <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2022 Brought to You By <a href="#">ONLINE BY ME</a></strong>
</footer> -->